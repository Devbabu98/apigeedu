 
var CustCode = context.getVariable('du.CustCode');
var From = context.getVariable('du.From');
var To = context.getVariable('du.To');
var Cc = context.getVariable('du.Cc');
var Bcc = context.getVariable('du.Bcc');
var RplyTo = context.getVariable('du.RplyTo');
var Subject = context.getVariable('du.Subject');
var BodyText = context.getVariable('du.BodyText');
var Language = context.getVariable('du.Language');
var TemplateId = context.getVariable('du.TemplateId');
var DocumentType = context.getVariable('du.DocumentType');
var ObjectId = context.getVariable('du.ObjectId');

//Soap Request Payload
var soapPayload = {
	"soapenv:Envelope" : {
		"#namespaces":{
			"soapenv": "http://schemas.xmlsoap.org/soap/envelope/" ,
			"web"  : "http://www.webservices.com/LCE/Du/WebServices" ,
			"head" :"http://www.du.ae/LCE/Header" ,
			"lcew" :"http://xmlns.du.ae/LCE/Business/LCEWebServiceRequest"  ,
			"sen" :"http://xmlns.du.ae/LCE/Business/CommunicationManagement/SendEmail_v3"
		},
		"soapenv:Header":{},
		"soapenv:Body":{
			"web:SendEmail_v3":{
				"Request":{
					"head:Header":{
						"head:RequestId": context.getVariable('du.api.requestId'),
						"head:Credentials":{
					        "head:ApplicationId":context.getVariable('du.config.lceApplicationId'),
					        "head:User":context.getVariable('du.config.lceUsername'),
					        "head:Password":context.getVariable('du.config.lcePassword'),						    
						},
						"head:CorrelationId":"",
					},
					"lcew:Body":{
                        "sen:From" :From ,
                        "sen:To" :To,
                        "sen:Cc" :Cc,
                        "sen:Bcc" :Bcc,
                        "sen:RplyTo" :RplyTo,
						"sen:Subject" :Subject,
						"sen:BodyText" :BodyText,
						"sen:Language" :Language,
						"sen:TemplateId" :TemplateId,
						"sen:Attachments":{
						    "sen:Attachment":{
							    "sen:DocumentType" :DocumentType,
								"sen:ObjectId" :ObjectId
								},
							},
						
										  
                     
					 }             
				}
			}
		}
	}
}; // End of soapPayload

context.setVariable('request.header.Content-Type','application/xml;charset="UTF-8"');
context.setVariable('request.header.SOAPAction','/Processes/BusinessResources/Services/LCEWebServices.serviceagent//SendEmail_v3');
context.setVariable('request.queryparam.serviceName','SendEmail_v3');
context.setVariable('request.queryparam.responseType','200');
context.setVariable('request.verb','POST');
context.setVariable('request.content', JSON.stringify(soapPayload));

