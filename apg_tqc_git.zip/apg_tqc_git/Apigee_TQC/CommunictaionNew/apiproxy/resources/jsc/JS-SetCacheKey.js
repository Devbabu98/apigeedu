 var operation = context.getVariable("proxy.pathsuffix");
var verb = context.getVariable("request.verb");


if(operation == "/sendEmail"){
        var customerCode = context.getVariable("request.queryparam.customerCode");
        
        var cacheKey = customerCode;
}    
context.setVariable('du.cacheKey',cacheKey);