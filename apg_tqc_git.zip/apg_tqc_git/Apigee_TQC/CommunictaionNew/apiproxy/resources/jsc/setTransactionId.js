var uuid = GUID.uuid();
context.setVariable('du.api.requestId', uuid);