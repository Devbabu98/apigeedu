var request = JSON.parse(context.getVariable("request.content"));
var customerCode = request.customerCode;
var accesstoken_customerCode = context.getVariable("accesstoken.customerCode");

if(!customerCode){
	context.setVariable('api-error.status_code', '400');
	context.setVariable('api-error.reason_phrase', 'Bad Request');
	throw new Error();
}

else if (customerCode != accesstoken_customerCode && customerCode){
	context.setVariable('api-error.status_code', '401');
	context.setVariable('api-error.reason_phrase', 'invalid authorization');
	throw new Error();
}