var responseStructure = 'SendEmail_v3Response';

try {
    var response = JSON.parse(context.getVariable('response.content'));

    context.setVariable('responseCode', response.Envelope.Body[responseStructure].Response.Header.ResponseCode);
            
    if (response.Envelope.Body[responseStructure].Response.Header.ErrorDescription){
    context.setVariable('errorDescription', response.Envelope.Body[responseStructure].Response.Header.ErrorDescription);
    }
    else{
    // NO ERROR MESSAGE RETURNED FROM TARGET SYSTEM
    context.setVariable('errorDescription', "")    
    }
    
    if(!(response.Envelope.Body[responseStructure].Response.Body)){
            context.setVariable('du.noResultsToReturn', 'true');
            context.setVariable('response.content', '{}');
    }
    else if(response.Envelope.Body[responseStructure].Response.Body.SearchIsComplete && !response.Envelope.Body[responseStructure].Response.Body.RequestList){
        context.setVariable('du.noResultsToReturn', 'true');
        context.setVariable('response.content', '{}');
    }
    else if(response.Envelope.Body[responseStructure].Response.Body.NumberOfResults == 0){
        context.setVariable('du.noResultsToReturn', 'true');
        context.setVariable('response.content', '{}');
    }
    else{
            context.setVariable('body', JSON.stringify(response.Envelope.Body[responseStructure].Response.Body));
            context.setVariable('response.content', JSON.stringify(response.Envelope.Body[responseStructure].Response.Body));
    }
}
catch(e) {
    context.setVariable('responseCode', '601');
    context.setVariable('errorDescription', 'transport error');
}