 
var CustCode = context.getVariable('request.queryparam.CustomerCode');

//Soap Request Payload
var soapPayload = {
	"soapenv:Envelope" : {
		"#namespaces":{
			"soapenv": "http://schemas.xmlsoap.org/soap/envelope/" ,
			"web"  : "http://www.webservices.com/LCE/Du/WebServices" ,
			"head" :"http://www.du.ae/LCE/Header" ,
			"lcew" :"http://xmlns.du.ae/LCE/Business/LCEWebServiceRequest"  ,
			"sen" :"http://xmlns.du.ae/LCE/Business/CommunicationManagement/SendEmail_v3"
		},
		"soapenv:Header":{},
		"soapenv:Body":{
			"web:SendEmail_v3":{
				"Request":{
					"head:Header":{
						"head:RequestId": context.getVariable('request.header.transaction-id'),
						"head:Credentials":{
					        "head:ApplicationId":context.getVariable('du.config.lceApplicationId'),
					        "head:User":context.getVariable('du.config.lceUsername'),
					        "head:Password":context.getVariable('du.config.lcePassword'),						    
						},
						"head:CorrelationId":"",
					},
					"lcew:Body":{
                        "sen:From" : "",
                        "sen:To" :"",
                        "sen:Cc" : "",
                        "sen:Bcc" : "",
                        "sen:RplyTo" : "",
						"sen:Subject" : "",
						"sen:BodyText" : "",
						
										  
                     
					 }             
				}
			}
		}
	}
}; // End of soapPayload

context.setVariable('request.header.Content-Type','application/xml;charset="UTF-8"');
context.setVariable('request.header.SOAPAction','/LCE/Business/CommunicationManagement/SendEmail_v3');
context.setVariable('request.queryparam.serviceName','SendEmail_v3');
context.setVariable('request.queryparam.responseType','200');
context.setVariable('request.verb','POST');
context.setVariable('request.content', JSON.stringify(soapPayload));

