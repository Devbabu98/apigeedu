var operation = context.getVariable("proxy.pathsuffix");
var verb = context.getVariable("request.verb");

if(verb == "GET"){
    if(operation == "/billing"){
        var CustomerId = context.getVariable("request.queryparam.CustomerId");
        var ContractID = context.getVariable("request.queryparam.ContractID");
        var StartDate = context.getVariable("request.queryparam.StartDate");
        var EndDate = context.getVariable("request.queryparam.EndDate");
        var cacheKey = CustomerId+'__'+ContractID+'__'+StartDate+'__'+EndDate;
    }
    else if(operation == "/billxml"){
        var customerCode = context.getVariable("request.queryparam.customerCode");
        var documentRefNumber = context.getVariable("request.queryparam.documentRefNumber");
        var cacheKey = customerCode+'__'+documentRefNumber;
    }
    else if(operation == "/balance"){
        var CustomerId = context.getVariable("request.queryparam.CustomerId");
        var CustomerIdPub = context.getVariable("request.queryparam.CustomerIdPub");
        var DirNum = context.getVariable("request.queryparam.DirNum");
        var BscsConType = context.getVariable("request.queryparam.BscsConType");
        var cacheKey = CustomerId+'__'+CustomerIdPub+'__'+DirNum+'__'+BscsConType;
    }
    else if(operation == "/documents"){
        var CustomerId = context.getVariable("request.queryparam.CustomerId");
        var CustomerIdPub = context.getVariable("request.queryparam.CustomerIdPub");
        var ContractID = context.getVariable("request.queryparam.ContractID");
        var ContractIDPub = context.getVariable("request.queryparam.ContractIDPub");
        var DocumentType = context.getVariable("request.queryparam.DocumentType");
        var StartDate = context.getVariable("request.queryparam.StartDate");
        var EndDate = context.getVariable("request.queryparam.EndDate");
        var BscsConType = context.getVariable("request.queryparam.BscsConType");
        var cacheKey = CustomerId+'__'+CustomerIdPub+'__'+ContractID+'__'+ContractIDPub+'__'+DocumentType+'__'+StartDate+'__'+EndDate+'__'+BscsConType;
    }
    context.setVariable('du.cacheKey',cacheKey);
}