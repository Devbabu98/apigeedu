var operation = context.getVariable("proxy.pathsuffix");
var verb = context.getVariable("request.verb")
 
  
  if(operation == "/billing" && verb == "GET"){
      var customerCode = context.getVariable("request.queryparam.CustomerCode");
      var MSISDN = context.getVariable("request.queryparam.MSISDN");
      var customerId = context.getVariable("request.queryparam.CustomerId");
  }
  else if((operation == "/billpdf" || operation == "/billxml") && verb == "GET"){
      var customerCode = context.getVariable("request.queryparam.customerCode");
      var MSISDN = context.getVariable("request.queryparam.MSISDN");
      var customerId = context.getVariable("request.queryparam.CustomerId");
  }
  else if((operation == "/balance" || operation == "/documents") && verb == "GET"){
      var customerCode = context.getVariable("request.queryparam.customerCode");
      var MSISDN = context.getVariable("request.queryparam.MSISDN");
      var customerId = context.getVariable("request.queryparam.CustomerId");
  }
  else if(operation == "/getibbill"  && verb == "GET"){
      var customerCode = context.getVariable("request.queryparam.customerCode");
   }
  else{
          var request = JSON.parse(context.getVariable("request.content"));
          var customerCode = request.customerCode;
          var MSISDN = request.MSISDN;
          var customerId = request.customerId;
  }
  
   var accesstoken_customerCode = context.getVariable("accesstoken.customerCode");
   var accesstoken_customerId = context.getVariable("accesstoken.customerId");
   var accesstoken_MSISDNList = context.getVariable("accesstoken.MSISDNList");
  
/*if(!MSISDN && !customerId && !customerCode){
	context.setVariable('api-error.status_code', '400');
	context.setVariable('api-error.reason_phrase', 'Bad Request');
	throw new Error();
}
else if (customerCode != accesstoken_customerCode && customerCode){
	context.setVariable('api-error.status_code', '401');
	context.setVariable('api-error.reason_phrase', 'invalid authorization');
	throw new Error();
}
else if (customerId != accesstoken_customerId && customerId){
	context.setVariable('api-error.status_code', '401');
	context.setVariable('api-error.reason_phrase', 'invalid authorization');
	throw new Error();
}
else if (!accesstoken_MSISDNList.includes('|'+ MSISDN + '|') && MSISDN){
	context.setVariable('api-error.status_code', '401');
	context.setVariable('api-error.reason_phrase', 'invalid authorization');
	throw new Error();
}*/