var flow = context.getVariable('proxy.pathsuffix');
var responseStructure = context.getVariable('du.config.soapMethodForResponse');

try {
    var response = JSON.parse(context.getVariable('response.content'));
    if(flow == '/billing'){
        context.setVariable('responseCode', response.Envelope.Body.GetBillInformationResponse.Response.Header.ResponseCode);
        context.setVariable('errorDescription', response.Envelope.Body.GetBillInformationResponse.Response.Header.ErrorDescription);
        context.setVariable('du.operation','GetBillInformation');
        if(!(response.Envelope.Body.GetBillInformationResponse.Response.Body)){
            context.setVariable('response.content', '{}');
        }else{
            context.setVariable('response.content', JSON.stringify(response.Envelope.Body.GetBillInformationResponse.Response.Body));
        }
    }
    else{
        context.setVariable('responseCode', response.Envelope.Body[responseStructure].Response.Header.ResponseCode);
        context.setVariable('errorDescription', response.Envelope.Body[responseStructure].Response.Header.ErrorDescription);
        if(!(response.Envelope.Body[responseStructure].Response.Body)){
            context.setVariable('du.noResultsToReturn', 'true');
            //context.setVariable('response.content', null);
        }
        else{
            context.setVariable('body', JSON.stringify(response.Envelope.Body[responseStructure].Response.Body));
            context.setVariable('response.content', JSON.stringify(response.Envelope.Body[responseStructure].Response.Body));
        }
    }
} 
catch(e) {
    context.setVariable('responseCode', '601');
    context.setVariable('errorDescription', 'transport error');
}