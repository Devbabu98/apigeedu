//Checks if the document is present in SANStorage and gets the directory name , then calls the SANStorage to download the file. if available
var directoryList,documentRefNumber,fileType,client_key,client_secret,clientKeySecretEncode,headerEncode;
var authHeader,requestHeaders,CustomerSegment,BillDate,PosptaidBill3976Date,postpaidBillDate,queryParamBillDate;
var queryParamBillDateDate,queryParamBillDateMonth,queryParamBillDateYear,billsubfolder;

documentRefNumber = context.getVariable("du.documentRefNumber");
fileType = context.getVariable("du.fileType");
var exchObjArray = [];
var resArray = [];
//Set Request Headers
client_key = context.getVariable("du.config.clientKey");
client_secret = context.getVariable("du.config.clientSecret");
clientKeySecretEncode = client_key+":"+client_secret;
headerEncode = Base64.encode(clientKeySecretEncode)
authHeader = "Basic "+headerEncode;
requestHeaders = {'Authorization' : authHeader};

//Changes of CR3973[START]
CustomerSegment = context.getVariable("request.queryparam.CustomerSegment"); //CON or ENT
BillDate = context.getVariable("request.queryparam.BillDate");               //From Query Param
PosptaidBill3976Date = context.getVariable("du.PostpaidBill3976Date");		// From KVM
postpaidBillDate = new Date(PosptaidBill3976Date);  						//Created Date Object
queryParamBillDate = new Date(BillDate);									//Created Date Object

//Logic to convert Date into yyyymmdd
queryParamBillDateDate = "" + queryParamBillDate.getDate().toString();
queryParamBillDateMonth = "" + (queryParamBillDate.getMonth()+1).toString();
if(queryParamBillDateMonth.length < 2)
    queryParamBillDateMonth = "0" + queryParamBillDateMonth;
if(queryParamBillDateDate.length < 2 )
    queryParamBillDateDate = "0" + queryParamBillDateDate;
queryParamBillDateYear = queryParamBillDate.getFullYear().toString();

//End Of Changes[CR3973][DILIPT]

//Get directoryList based on file format
if(fileType == "xml") {
    directoryList = context.getVariable("du.config.directoryListXML");
    //print("XML  : ",directoryList);
    
}
else {
    directoryList = context.getVariable("du.config.directoryListPDF");  ///Fetch All Extisting Directory List
    //print("PDF  :",directoryList);
}

//print("queryParamBillDate",queryParamBillDate);
//print("postpaidBillDate",postpaidBillDate);
//[CR-3976][Modification]
if(queryParamBillDate !== "" && (queryParamBillDate > postpaidBillDate))
{
   var concatBillDate = [queryParamBillDateYear,queryParamBillDateMonth,queryParamBillDateDate].join("");
   //print("concatBillDate",concatBillDate);
   billsubfolder = CustomerSegment+"_"+concatBillDate;
   directoryList = context.getVariable("du.PosptaidBillPaths");
   //print("Directory List"+directoryList);
   //print("Into Comparision",billsubfolder);
}
//[CR3976][modifcation End]
var dirArray = directoryList.split(",");
//print("dirArray"+dirArray);
//URL of SANStorage
var sanStorageUrl = context.getVariable("du.config.sanStorageUrl");
//print("sanStorageUrl"+sanStorageUrl);

//Variable to route the request to local proxy chaining
var routeRequest = "local";
	for (var i = 0; i < dirArray.length; i++) {
	   	if(queryParamBillDate === "" || (queryParamBillDate < postpaidBillDate))
		{
		var url = sanStorageUrl+"?dir_name="+dirArray[i]+"&file_name="+documentRefNumber+"."+fileType+"&operation=exists";
		//print("Above if Statement URL:",url);
		    
		}
		else
		{
			////print(dirArray[i]+billsubfolder);
			//print(documentRefNumber);
			dirArray[i] = dirArray[i]+billsubfolder+"/";
            var url = sanStorageUrl+"?dir_name="+dirArray[i]+"&file_name="+documentRefNumber+"."+fileType+"&operation=exists";
           //	print("Else Part :",url);
        }			
		    var operation = "GET";
    		var request = new Request(url,operation,requestHeaders);
			//print(request);
    		exchObjArray.push(request);
	}
	
	for (var i = 0; i < exchObjArray.length; i++) {
	    var res = httpClient.send(exchObjArray[i]);
	    res.waitForComplete();
	    
	    if (res.isSuccess()) {
	      // print(exchObjArray[i] + ' - ' + res.getResponse().content);
		    resArray.push(res.getResponse().content);
		}
	}

	for (var i = 0; i < resArray.length; i++) {
		//if (resArray[i].isComplete()) {
		    var response = resArray[i];
		    //print('[' + response + ']');
			if(response == "true"){
			//	print(dirArray[i]);
			    var fileAvailableInDir = dirArray[i];
			//	print(fileAvailableInDir);
			    break;
			}
		//}
	}

	if (fileAvailableInDir) {
		context.setVariable("fileInDirectory",fileAvailableInDir);
		context.setVariable("searchFileName",documentRefNumber+"."+fileType);
		context.setVariable("authHeader",authHeader);
		context.setVariable("du.api.route_request",routeRequest);
	}
	else{
	    context.setVariable('responseCode', '700');
		context.setVariable('errorDescription', 'File Not Found');
	}