var body = JSON.parse(context.getVariable("body"));
 
var myMap = [
    JSMapr.MAP1("/CustomerBalance",
        [
            JSMapr.MOVE("/DueDate", "/dueDate"),
            JSMapr.MOVE("/LastBilledDate", "/lastBilledDate"),
            JSMapr.MOVE("/OutstandingAmount", "/outstandingAmount"),
            JSMapr.MOVE("/PreviousBalance", "/previousBalance"),
            JSMapr.MOVE("/TotalInvoiceAmount", "/totalInvoiceAmount"),
            JSMapr.MOVE("/TotalPaidAmount", "/totalPaidAmount"),
            JSMapr.MOVE("/UnbilledAmount", "/unbilledAmount"),
            JSMapr.MOVE("/TotalOpenAmount", "/totalOpenAmount"),
            JSMapr.MOVE("/TotalOccAmount", "/totalOccAmount")
        ]
    ),
    JSMapr.MOVE("/CustomerBalance", "/customerBalance")
];

var mapr = new JSMapr();
mapr.setMapCommands(myMap);
body = mapr.map(body);

context.setVariable("response.content", JSON.stringify(body));