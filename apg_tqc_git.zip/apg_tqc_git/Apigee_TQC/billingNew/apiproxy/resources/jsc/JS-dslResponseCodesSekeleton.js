var response = JSON.parse(context.getVariable("response.content"));
   
switch(response.return.code){
	case "200":
        delete response.return.code;
		delete response.return.statusCode;
		delete response.return.messageResource;
		context.setVariable('response.content', JSON.stringify(response.return));
		break;
	default:
        if(response.return.messageResource.messageValue){
            var error = { "error": { "code": response.return.code,"message": response.return.messageResource.messageValue } };
        }
        else{
            var error = { "error": { "code": response.return.code,"message": "" } };
        }
            context.setVariable('response.content', JSON.stringify(error));
}