 var ibUrl = context.getVariable('du.config.ibtargetUrl');
var id = context.getVariable('du.id');

//context.setVariable('target.url', "http://172.24.246.105/depositorydirect/L/?id=" + id);

 
context.setVariable('target.url', "http://" +ibUrl + id);