var operation = context.getVariable("proxy.pathsuffix");
var verb = context.getVariable("request.verb");

var customerCode;
var customerId;
var MSISDN;

  if(operation == "/service" && verb == "POST"){
      var request = JSON.parse(context.getVariable("request.content"));
      MSISDN = request.msisdn;
  }
  else{
          var request = JSON.parse(context.getVariable("request.content"));
          MSISDN = request.msisdn;
  }
  
var accesstoken_customerCode = context.getVariable("accesstoken.customerCode");
var accesstoken_customerId = context.getVariable("accesstoken.customerId");
var accesstoken_MSISDNList = context.getVariable("accesstoken.MSISDNList");

if(!customerCode && !MSISDN && !customerId){
	context.setVariable('api-error.status_code', '400');
	context.setVariable('api-error.reason_phrase', 'Bad Request');
	throw new Error();
}
else if (customerCode != accesstoken_customerCode && customerCode){
	context.setVariable('api-error.status_code', '401');
	context.setVariable('api-error.reason_phrase', 'invalid authorization');
	throw new Error();
}
else if (customerId != accesstoken_customerId && customerId){
	context.setVariable('api-error.status_code', '401');
	context.setVariable('api-error.reason_phrase', 'invalid authorization');
	throw new Error();
}
else if (!accesstoken_MSISDNList.includes('|'+ MSISDN + '|') && MSISDN){
	context.setVariable('api-error.status_code', '401');
	context.setVariable('api-error.reason_phrase', 'invalid authorization');
	throw new Error();
}