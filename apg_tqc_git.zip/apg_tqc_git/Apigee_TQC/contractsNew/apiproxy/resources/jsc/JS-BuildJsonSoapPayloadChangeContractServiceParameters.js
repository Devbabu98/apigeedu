var inputJson = context.getVariable("request.content");
     var input = JSON.parse(inputJson);

    var soapPayload = {
	"soapenv:Envelope" : {
		"#namespaces":{
			"soapenv" : "http://schemas.xmlsoap.org/soap/envelope/",
			"web" : "http://www.webservices.com/LCE/Du/WebServices",
			"head" : "http://www.du.ae/LCE/Header",
			"lcew" : "http://xmlns.du.ae/LCE/Business/LCEWebServiceRequest" ,
			"chan" : "http://xmlns.du.ae/LCE/Business/ServiceManagement/ChangeContractServiceParameters"
		},
		"soapenv:Header":{},
		"soapenv:Body":{
			"web:ChangeContractServiceParameters":{
				"Request":{
					"head:Header":{
						"head:RequestId": context.getVariable("request.header.transaction-id"),
						"head:Credentials":{
							"head:ApplicationId": context.getVariable("du.config.lceApplicationId"),
							"head:User": context.getVariable("du.config.lceUsername"),
							"head:Password": context.getVariable("du.config.lcePassword"),
						},
						"head:CorrelationId": "",
					},
					"lcew:Body": buildRequestBody(input)
				}
			}
		}
	}
};
context.setVariable("request.content", JSON.stringify(soapPayload));

function buildRequestBody(input){
	return {
		"chan:COM" :{
			"chan:DOCUMENT" : {
				"chan:CUSTOMER" :{
				     "chan:CONTRACT" : getContractArray(input.customer.contracts)
				}
			}
		}
	}
}

function getContractArray(contracts){
	var contractsArray = [];
	if(contracts){
		for (var i = 0; i < Object.keys(contracts).length; i++) {
			contractsArray.push({
				"chan:CONTRACT_ID": contracts[i].contractId,
				"chan:SERVICE" : getServicesArray(contracts[i].services)
			});	
		}

	}

	return contractsArray;
}


function getServicesArray(services){
	var servicesArray = [];
	if(services){
		for (var i = 0; i < Object.keys(services).length; i++) {
			servicesArray.push({
				"chan:SERVICE_ID": services[i].serviceId,
				"chan:SERVICE_PACKAGE_CODE": services[i].servicePackageCode,
				"chan:PROFILE_ID": services[i].profileId,
				"chan:PARAMETER" : getParametersArrayOfService(services[i].parameters)
			});
		}
	}
	return servicesArray;
}

function getParametersArrayOfService(parameters){
	var parametersArray = [];
	if(parameters){
		for (var i = 0; i < Object.keys(parameters).length; i++) {
			parametersArray.push({
				"chan:NUMBER": parameters[i].number,
				"chan:TYPE": parameters[i].type,
				"chan:ACTION": parameters[i].action,
				"chan:VALUE" : getValueArrayOfParameters(parameters[i].values)
			});
		}
	}
	return parametersArray;
}

function getValueArrayOfParameters(values){
	var valuesArray = [];
	if(values){
		for (var i = 0; i < Object.keys(values).length; i++) {
			valuesArray.push({
				"chan:VALUE": values[i].value,
				"chan:DESCRIPTION": values[i].description
			});
		}
	}
	return valuesArray;
}