   var body = JSON.parse(context.getVariable("body"));
 
 var myMap = [
    JSMapr.IFTYPE("/Customer_List", "array",
    [
        JSMapr.MAPEACH("/Customer_List",
            [
                JSMapr.MOVE("/Customer_Code", "/customerCode"),
                JSMapr.MOVE("/Customer_Type", "/customerType"),
                JSMapr.MOVE("/Out_Standing_Balance", "/outstandingBalance"),
                JSMapr.IFTYPE("/Contract_List", "array",
                    [
                        JSMapr.MAPEACH("/Contract_List",
                            [
                                JSMapr.MOVE("/Msisdn", "/maskedMSISDN"),
                                JSMapr.MOVE("/Contract_Type", "/contractType"),
                                JSMapr.MOVE("/Segment", "/contractSegment"),
                                JSMapr.MOVE("/Rateplan_Shdes", "/rateplanDesc"),
                                JSMapr.MOVE("/Rateplan_Des", "/rateplanShortDesc")
                                ]
                        ),
                    JSMapr.MOVE("/Contract_List", "/customerAccountsContracts")
                    ]
                ),
                JSMapr.MAP1("/Contract_List",
                    [
                        JSMapr.MOVE("/Msisdn", "/maskedMSISDN"),
                        JSMapr.MOVE("/Contract_Type", "/contractType"),
                        JSMapr.MOVE("/Segment", "/contractSegment"),
                        JSMapr.MOVE("/Rateplan_Shdes", "/rateplanDesc"),
                        JSMapr.MOVE("/Rateplan_Des", "/rateplanShortDesc"),
                        JSMapr.MOVE("/Contract_List", "/customerAccountsContracts")
                    ]
               ),
                JSMapr.MOVE("/Contract_List", "/customerAccountsContracts")
                ]
        ),
        JSMapr.MOVE("/Customer_List", "/customerAccounts")
    ]
    ),
    JSMapr.MAP1("/Customer_List",
    [
                JSMapr.MOVE("/Customer_Code", "/customerCode"),
                JSMapr.MOVE("/Customer_Type", "/customerType"),
                JSMapr.MOVE("/Out_Standing_Balance", "/outstandingBalance"),
                JSMapr.IFTYPE("/Contract_List", "array",
                    [
                        JSMapr.MAPEACH("/Contract_List",
                            [
                                JSMapr.MOVE("/Msisdn", "/maskedMSISDN"),
                                JSMapr.MOVE("/Contract_Type", "/contractType"),
                                JSMapr.MOVE("/Segment", "/contractSegment"),
                                JSMapr.MOVE("/Rateplan_Shdes", "/rateplanDesc"),
                                JSMapr.MOVE("/Rateplan_Des", "/rateplanShortDesc")
                                ]
                        ),
                    JSMapr.MOVE("/Contract_List", "/customerAccountsContracts")
                    ]
                ),
                JSMapr.MAP1("/Contract_List",
                    [
                        JSMapr.MOVE("/Msisdn", "/maskedMSISDN"),
                        JSMapr.MOVE("/Contract_Type", "/contractType"),
                        JSMapr.MOVE("/Segment", "/contractSegment"),
                        JSMapr.MOVE("/Rateplan_Shdes", "/rateplanDesc"),
                        JSMapr.MOVE("/Rateplan_Des", "/rateplanShortDesc"),
                        JSMapr.MOVE("/Contract_List", "/customerAccountsContracts")
                    ]
               ),
                JSMapr.MOVE("/Contract_List", "/customerAccountsContracts")
            ]
        ),
        JSMapr.MOVE("/Customer_List", "/customerAccounts")
];

var mapr = new JSMapr();
mapr.setMapCommands(myMap);
body = mapr.map(body);

context.setVariable("response.content", JSON.stringify(body));