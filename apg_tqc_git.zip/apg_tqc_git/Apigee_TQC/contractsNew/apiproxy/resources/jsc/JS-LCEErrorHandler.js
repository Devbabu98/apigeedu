 try {
    var response = JSON.parse(context.getVariable('response.content'));
    context.setVariable('responseCode', response.Envelope.Body.ChangeContractServiceParametersResponse.Response.Header.ResponseCode);
    context.setVariable('errorDescription', response.Envelope.Body.ChangeContractServiceParametersResponse.Response.Header.ErrorDescription);  
} catch(e) {
    context.setVariable('responseCode', '601');
    context.setVariable('errorDescription', 'transport error');
}