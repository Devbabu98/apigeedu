var requestBody = context.getVariable("request.content");
var uuid = GUID.uuid();
context.setVariable('du.api.requestId', uuid);

if(requestBody){
requestBody = JSON.parse(requestBody);
     context.setVariable('du.consentFlag',requestBody.creditScore.ConsentFlag);
     context.setVariable('du.providerApplicationNo',requestBody.creditScore.ProviderApplicationNo);
     context.setVariable('du.contractType',requestBody.creditScore.ContractType);
     context.setVariable('du.Role',requestBody.creditScore.Role);
     context.setVariable('du.fullNameEN',requestBody.creditScore.FullNameEN);
     context.setVariable('du.gender',requestBody.creditScore.Gender);
     context.setVariable('du.dob',requestBody.creditScore.DOB);
     context.setVariable('du.EmiratesId',requestBody.creditScore.EmiratesId);
     context.setVariable('du.primaryMobileNo',requestBody.creditScore.PrimaryMobileNo);
     context.setVariable('du.providerSubjectNo',requestBody.creditScore.ProviderSubjectNo);
     context.setVariable('du.nationality',requestBody.creditScore.Nationality);
     context.setVariable('du.passport',requestBody.creditScore.Passport);
     context.setVariable('du.fullNameArabic',requestBody.creditScore.FullNameArabic);
     context.setVariable('du.gid',requestBody.creditScore.GId);
     context.setVariable('du.mid',context.getVariable('request.header.Postman-Token'));
    var dateSystemFormat = new Date();
    
    
    var getHour = dateSystemFormat.getHours().toString();
    var getMinute = dateSystemFormat.getMinutes().toString();
    var getSecond = dateSystemFormat.getSeconds().toString();
    var miliSecond = dateSystemFormat.getMilliseconds().toString()+"0000";
    var fullYear = dateSystemFormat.getFullYear().toString();
    var getMonths = (dateSystemFormat.getMonth() + 1).toString();
    var getDate = dateSystemFormat.getDate().toString(); 
    
    
     getDate =  getDate.length < 2 ? "0"+getDate : getDate;
     getMonths = this.getMonths.length < 2 ? "0"+getMonths : getMonths;
     
     getHour = this.getHour.length < 2 ? "0"+getHour : getHour;
     getMinute = this.getMinute.length < 2 ? "0"+getMinute : getMinute;
     getSecond = this.getSecond.length < 2 ? "0"+getSecond : getSecond;
     
    var dateRequiredFormat = fullYear+"-"+getMonths+"-"+getDate+"T"+getHour+":"+getMinute+":"+getSecond+"."+miliSecond+"+04:00";
    context.setVariable('du.date',dateRequiredFormat);
    

                

}else{
    context.setVariable('api-error.code', 'NB_40002');
    context.setVariable('api-error.error', 'BodyPayloadMissing');
    context.setVariable('api-error.message', 'Invalid body params passed');
    context.setVariable('api-error.status_code', '400');
    context.setVariable('api-error.reason_phrase', 'Bad Request');
    throw new Error();
}