/**
 * Check for JSON payload
 */

var jsonPayload = context.getVariable("request.content");
var message = "";
if(jsonPayload){
	try{
		var jsonPayload = JSON.parse(jsonPayload);
	}catch(e){
		message = "Invalid JSON payload." + e;
	}
}else{
	message = "Request content is empty. JSON payload is required.";
}

if(message){
    print('called')
	context.setVariable('api-error.errormessage', 'BadRequestContent');
	context.setVariable('api-error.responsecode', '400');
	context.setVariable('api-error.errorcode', '400');
	context.setVariable('api-error.responsemessage', message);
	throw new Error()
}