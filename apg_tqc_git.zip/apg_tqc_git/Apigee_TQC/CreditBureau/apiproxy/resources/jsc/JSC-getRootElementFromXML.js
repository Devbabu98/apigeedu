try{
    var responseAecb = JSON.parse(context.getVariable("response.content"));
    var xml = responseAecb.Envelope.Body.MGResponse;
    context.setVariable('du.xml',xml);
}catch(e)
{
    context.setVariable('api-error.code', 'NB_40002');
    context.setVariable('api-error.error', 'BodyPayloadMissing');
    context.setVariable('api-error.message', 'Invalid body params passed');
    context.setVariable('api-error.status_code', '400');
    context.setVariable('api-error.reason_phrase', 'Bad Request');
    throw new Error();
    
}