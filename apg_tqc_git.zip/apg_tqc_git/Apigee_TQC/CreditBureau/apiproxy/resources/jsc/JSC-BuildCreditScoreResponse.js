 var acebIndex,acebResponseId,aecbIndex,aecbRange,aecbCode,aecbDesc,responsePayload,error;
 
 try
 {
    sRange = context.getVariable("du.config.startingRange");
    eRange = context.getVariable("du.config.endRange");
    acebIndex = context.getVariable("apigee.aecb.index");
    aecbRange = context.getVariable("apigee.aecb.range");
    acebResponseId = context.getVariable("apigee.aecb.respId");
    aecbCode = context.getVariable("apigee.aecb.no");
    aecbDesc = context.getVariable("apigee.aecb.desc");

    if(acebIndex !== null && acebIndex!== "")
    {
         if( sRange <= aecbRange  && aecbRange <= eRange )
          {
              var responsePayload = {
                "creditScore":{
                                "Index": "NH" ,
                                "Range":aecbRange
                            },
                               "Code":"200",
                               "Message": "OK"
        };
          }
       
       else {
        var responsePayload = {
                "creditScore":{
                                "Index":acebIndex,
                                "Range":aecbRange
                            },
                               "Code":"200",
                               "Message": "OK"
           };
       }

     context.setVariable('response.content',JSON.stringify(responsePayload));
    }
    else{
        
        if(aecbCode !== null && aecbCode !== "")
        {
           
           
            var error = {
                                    "Code":aecbCode.toString(),
                                    "Message":aecbDesc 
                    };
        }
        else
        {
             
          var error =   {
                                    "Code":"701",
                                    "Message": "No Score Received from Target"
                                };

        }
        
        context.setVariable('response.content',JSON.stringify(error)); 
    }
  
 }
 catch(e)
 {
      context.setVariable('api-error.code', 'NB_40002');
    context.setVariable('api-error.error', 'MissingParameter');
    context.setVariable('api-error.message', 'Missing Parameter for getCustomerinfo');
    context.setVariable('api-error.status_code', '400');
    context.setVariable('api-error.reason_phrase', 'Bad Request');
    throw new Error();
     
     
 }